<?php


$host = "localhost";

$user = "u483173002_root";

$pw = "12345/Proyecto";

$db = "u483173002_practica1b";


?>